public class Main {
    public static void main(String[] args) {
        TaskManagement tms = new TaskManagement();

        // Adding tasks
        tms.addTask(new Task("T001", "Design Database", "In Progress"));
        tms.addTask(new Task("T002", "Develop API", "Pending"));
        tms.addTask(new Task("T003", "Test Application", "Completed"));

        // Traversing tasks
        System.out.println("Task list:");
        tms.traverseTasks();

        // Searching for a task
        Task task = tms.searchTask("T002");
        if (task != null) {
            System.out.println("Task found: " + task);
        } else {
            System.out.println("Task not found.");
        }

        // Deleting a task
        tms.deleteTask("T002");
        System.out.println("Task list after deletion:");
        tms.traverseTasks();
    }
}
