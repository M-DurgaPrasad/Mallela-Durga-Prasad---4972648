package org.library.repository;

public class BookRepository {
    BookRepository()
    {
        System.out.println("Bookrepository obj is created");
    }
}
