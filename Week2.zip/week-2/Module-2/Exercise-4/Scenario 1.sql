Scenario 1: Calculate the Age of Customers for Eligibility Checks

CREATE OR REPLACE FUNCTION CalculateAge(p_dob DATE) RETURN NUMBER IS
    l_age NUMBER;
BEGIN
    l_age := FLOOR(MONTHS_BETWEEN(SYSDATE, p_dob) / 12);
    RETURN l_age;
END;
/


